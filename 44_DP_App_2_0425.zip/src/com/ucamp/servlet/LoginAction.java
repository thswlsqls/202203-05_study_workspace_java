package com.ucamp.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.ucamp.model.MemberDAO;

public class LoginAction implements Action {

	@Override
	public String action(HttpServletRequest request) throws ServletException, IOException {
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		
		String url="login.jsp";
		//DAO
		try {
			if(new MemberDAO().login(id, pw).length() !=0) {
				
				url="memberInfo.jsp";
			}
//		}catch(ClassNotFoundException e) {
//			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return url;
	}

}
