package com.ucamp.servlet;

import javax.servlet.http.HttpServletRequest;

public class logoutUIAction implements Action {

	@Override
	public String action(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return "login.jsp";
	}

}
