package com.oopsw;

public class Programmer extends Employee {

	private String softwareName;

	public Programmer(String employeeNumber, String name, String departmentName, int salary, String softwareName) {
		super(employeeNumber, name, departmentName, salary);
		setSoftwareName(softwareName);
	}
	
	public String getSoftwareName() {
		return softwareName;
	}
	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}

	@Override
	public String toString() {
		return super.toString()+" ," + "���SW�̸�=" + softwareName;
	}
	
	
	
	
}
