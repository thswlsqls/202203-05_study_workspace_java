package com.oopsw;

public class Employee {

	private String employeeId;
	private String name;
	private String departmentName;
	private int salary;
	
	public Employee() {
		super();
	}
	public Employee(String employeeId, String name, String departmentName, int salary) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		setDepartmentName(departmentName);
		this.salary = salary;
	}
	
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getName() {
		return name;
	}
	public int getSalary() {
		return salary;
	}
	
	@Override
	public String toString() {
		return "���=" + employeeId + ", �̸�=" + name + ", �μ���=" + departmentName
				+ ", �޿�=" + salary;
	}
	
	
	
	
	
}
